<?php
highlight_file(__FILE__);
if(isset($_GET['code'])){
    $code=$_GET['code'];
    if (!preg_match('/sys|pas|read|file|ls|cat|tac| |head|tail|more|bash|less|php|base|echo|cp|~|\$|\*|\+|\^|scan|\.|local|current|chr|crypt|show_source|high|readgzfile|dirname|time|next|all|hex2bin|im|shell/i',$code)){
        eval($code);
    }
    else{
        die("nonono");
    }
}else{
    die("code is nothing");
}